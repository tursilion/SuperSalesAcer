19991208

Modified again Dec 8 99 to correct speed on even faster PCs. A slight
bug in my last fix prevented it from working... now it should be good
forever.

Modified Jan 1, 97 to correct speed problem on fast PCs.

---

Welcome to the world of Door-to-Door sales!

People hate door-to-door salesmen, and some go to extreme lengths to
make them feel unwelcome. Many salesmen just give up in cases like
this.

Enter our hero.

Super Sales Acer is determined not to let a few little obstacles stop him.
He vows to make his sale!

The game.

Super Sales Acer requires a reasonable IBM clone. I've run it on a 4 MHZ
XT, but it's a tad slow.

You NEED VGA. (I'm not sure why I wrote this, since it supports CGA...)

To run the game, enter "SALEACER" at the DOS prompt.

The object of every level is to touch all the special bricks and turn them
into ordinary ones. Why? Wouldn't be much of a game otherwise. Avoid
everything that moves... here are the enemies to watch for:

Rat - runs randomly back and forth, can't make up his mind. Likes to nibble
toes.

Crab - wanders back and forth

Bomb - walks hesitantly towards you, fuse ignites when close. Get away! He
       WILL explode! :)

Trap - large bear traps with sharp teeth waiting for a careless salesman

Crystal - large, pretty, and very sharp. Jump over them.

Icicle - will fall when you get close

Spot - the pet of the home, guarding the door

---

You can also ride on moving platforms to get where you need to go. often you
will have to. Stay out of the water and the lava - salesmen don't like
either one.

If you finish the ninth level (getting past Spot), you make it to the door.
You'll get some information, too.

---

Keys:

```
         E = up
  S = left     D = right
         X = down

       SPACE = jump
```

Press a movement key ONCE to move - DO NOT hold it down!! Press the same key AGAIN to stop.

If you don't like these keys, write me and complain. :)

Known Bugs
---

- Sometimes pops up on top of platforms you didn't think you could jump up to. -- That's not a bug, that's a feature!! :)

- Graphics sometimes garble when two moving objects overlap (or come close). -- Yeah. That sucks.

---

                         
This game is copyright 1995 by M.Brent, all rights reserved, like it says
on the title page, and the logoff screen, and the game win page...

Like it says in the quit screen, this program is ???WARE. If you like it
for some weird reason, send me something, anything! Money, postcards,
letters, tickets to weird events, dolphins, cars, written promises to
buy me CocaCola, etc etc....
